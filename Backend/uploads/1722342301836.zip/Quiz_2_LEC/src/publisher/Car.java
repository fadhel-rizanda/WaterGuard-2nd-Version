package publisher;

import java.util.ArrayList;

import observer.Observer;

public class Car implements Publisher {
	ArrayList<Observer> observerList = new ArrayList<>();
	String componentType,  componentStatus;
	
	@Override
	public void addObserver(Observer observer) {
		// TODO Auto-generated method stub
		observerList.add(observer);
		
	}

	@Override
	public void removeObserver(Observer observer) {
		// TODO Auto-generated method stub
		observerList.remove(observer);
		
	}

	@Override
	public void updateIndicator() {
		// TODO Auto-generated method stub
		for(Observer observer:observerList) {
			observer.createIndicator(componentType, componentStatus);
		}		
	}
	
	public void createUpdateIndicator(String componentType, String componentStatus) {
		this.componentType = componentType;
		this.componentStatus = componentStatus;
		updateIndicator();
	}

}
