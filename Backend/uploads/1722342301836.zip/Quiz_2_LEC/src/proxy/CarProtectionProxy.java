package proxy;

import model.Key;

public class CarProtectionProxy {
	Key key;
	String carKey;
	String keyPassword;
	public CarProtectionProxy(String carKey, String keyPassword) {
		super();
		this.carKey = carKey;
		this.keyPassword = keyPassword;
		key = new Key();
	}
	
	public void startCar() {
		if(authenticate()) {
			key.startComponent();
		}else {
			System.out.println("wrong key Password!");
		}
	}

	private boolean authenticate() {
		// TODO Auto-generated method stub
		return "turnOnCar123".equals(keyPassword);
	}
	

	
	

}
