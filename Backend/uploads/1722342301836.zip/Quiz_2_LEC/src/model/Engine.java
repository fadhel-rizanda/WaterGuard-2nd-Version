package model;

public class Engine implements CarComponent {

	@Override
	public void startComponent() {
		// TODO Auto-generated method stub
		System.out.println("Engine is on");
		
	}

	@Override
	public void endComponent() {
		// TODO Auto-generated method stub
		System.out.println("Engine is off");
		
	}

}
