package model;

public class Key implements CarComponent {

	@Override
	public void startComponent() {
		// TODO Auto-generated method stub
		System.out.println("Car Unlocked");
		
	}

	@Override
	public void endComponent() {
		// TODO Auto-generated method stub
		System.out.println("Car Locked");
		
	}

}
