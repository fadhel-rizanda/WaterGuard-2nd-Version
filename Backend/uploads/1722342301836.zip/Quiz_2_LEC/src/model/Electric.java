package model;

public class Electric implements CarComponent {

	@Override
	public void startComponent() {
		// TODO Auto-generated method stub
		System.out.println("Electricity is on");
		
	}

	@Override
	public void endComponent() {
		// TODO Auto-generated method stub
		System.out.println("Electricity is off");
		
	}

}
