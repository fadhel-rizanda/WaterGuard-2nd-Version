package model;

public interface CarComponent {
	public void startComponent();
	public void endComponent();

}
