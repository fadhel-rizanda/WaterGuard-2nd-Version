package facade;

import model.Electric;
import model.Engine;
import model.Key;

public class ComponentFacade {
	Electric electric = new Electric();
	Engine engine = new Engine();
	Key key = new Key();
	String carStatus = "off";
	
	public void startCar() {
		electric.startComponent();
		engine.startComponent();
		this.carStatus = "On";
	}
	
	public void endCar() {
		engine.endComponent();
		electric.endComponent();
		key.endComponent();
		this.carStatus = "off";
	}
	

}
