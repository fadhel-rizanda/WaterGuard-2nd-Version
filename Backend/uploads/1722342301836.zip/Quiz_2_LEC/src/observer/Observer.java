package observer;

public interface Observer {
	public void createIndicator(String componentType, String componentStatus);

}
