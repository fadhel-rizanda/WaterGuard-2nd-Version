package observer;

import java.util.ArrayList;
import java.util.HashMap;

public class Driver implements Observer {

	HashMap<String, ArrayList<String>>indicators = new HashMap<>();
	ArrayList<String> speedometer = new ArrayList<>();
	ArrayList<String> headUnit = new ArrayList<>();
	
	public Driver() {
		speedometer.add("Trip A");
		speedometer.add("Trip B");
		speedometer.add("Trip C");
		
		headUnit.add("Front");
		headUnit.add("Central");
		headUnit.add("Back");
		
		indicators.put("Speedometer", speedometer);
		indicators.put("HeadUnit", headUnit);
	}

	@Override
	public void createIndicator(String componentType, String componentStatus) {
		// TODO Auto-generated method stub
		ArrayList<String> carIndicators = indicators.get(componentType) ;
		for(String componentName:carIndicators) {
			if(componentName.equals("Speedometer")) {
				System.out.println(componentName+" in speedometer is '"+componentStatus+"'");
			}else {
				System.out.println(componentName+" in head unit is '"+componentStatus+"'");
			}
		}
		
	}
	
	
}
