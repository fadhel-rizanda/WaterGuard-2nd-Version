package main;

import facade.ComponentFacade;

import observer.Driver;
import proxy.CarProtectionProxy;
import publisher.Car;

public class Main {
//	Nama: Fadhel Baihaqi Rizanda
//	NIM: 2602086476
	
	
	public Main() {
		// TODO Auto-generated constructor stub
		String car = "SportCar";
		String carKey = "turnOnCar123";
		String componentType = "HeadUnit";
		String componentStatus = "On";
		
		CarProtectionProxy proxy = new CarProtectionProxy(carKey, car);
		ComponentFacade facade = new ComponentFacade();
		Driver observer = new Driver();
		Car publisher = new Car();
		
		proxy.startCar();
		facade.startCar();
		publisher.addObserver(observer);
		publisher.createUpdateIndicator(componentType, componentStatus);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
